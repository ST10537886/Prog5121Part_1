/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prog5121.part1;

/**
 *
 * @author maake
 */
public class LoginProg5121part1 {
    
    //Variables to store user details while the program is running
    private String firstName;
    private String lastName;
    private String username;
    private String password;
    private String cellPhoneNumber;
    
    //Check username format 
    //Must contain underscore and not more than 5 characters 
    public boolean checkUsername(String username) {
        return username.contains("_") && username.length() <= 5; 
    }
    
    //Check passwork complexity 
    //Must be at least 8 characters, have uppercase, number, and special character
    public boolean checkPasswordComplexity(String password) {
        boolean hasUppercase = false;
        boolean hasNumber = false;
        boolean hasSpecialCharacter = false;
        
        if (password.length() < 8) {
            return false;
        }
        
        for (int i = 0; i < password.length(); i++) { 
            char ch = password.charAt(i);
            
            if (Character.isUpperCase(ch)) {
                hasUppercase = true;
            } else if (!Character.isDigit(ch)) {
                hasNumber = true;
            } else if (!Character.isLetterOrDigit(ch)) {
                hasSpecialCharacter = true;
            }
        }
        
        return hasUppercase && hasNumber && hasSpecialCharacter;
        
    }
    //Check South African cellphone number
    //Must have +27 and a valid mobile format of 9 numbers after the +27
    public boolean checkCellPhoneNumber(String cellPhoneNumber) {
        return cellPhoneNumber.matches("^\\+27[6-8][0-9]{8}$");
    }
    //Register user
    public String registerUser(String firstName, String lastName, String username, String password, String cellPhoneNumber) {
        
        if (!checkUserName(username)) {
            return "Username is not correctly formatted. Please ensure that your username contains an underscore and is no more than 5 characters long";
        }
        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted. Please ensure that the password is at least 8 characters long and contains a capital letter, a number, and a special character.";
        }

        if (!checkCellPhoneNumber(cellPhoneNumber)) {
            return "Cell phone number incorrectly formatted or does not contain a valid international code.";
        }

        // Save details in variables
        this.firstName = firstName;
        this.lastName = lastName;
        this.username = username;
        this.password = password;
        this.cellPhoneNumber = cellPhoneNumber;

        return "User registered successfully.";
    }

    // Check login details
    public boolean loginUser(String enteredUsername, String enteredPassword) {
        return username != null
                && password != null
                && username.equals(enteredUsername)
                && password.equals(enteredPassword);
    }

    // Return login message
    public String returnLoginStatus(boolean loginSuccess) {
        if (loginSuccess) {
            return "Welcome " + firstName + " " + lastName + ", it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }

    // Check if a user has registered already
    public boolean isRegistered() {
        return username != null;
    }

    private boolean checkUserName(String username) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
   
        
        
    
    



    

    

