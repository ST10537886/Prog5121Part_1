/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prog5121.part1;
import java.util.Scanner;
/**
 *
 * @author maake
 */
public class Prog5121Part1 {

    public static void main(String[] args) {
        
        //Scanner for user input
        Scanner input = new Scanner(System.in);
        
        //Create object of Login class
        LoginProg5121part1 login = new LoginProg5121part1();
        
        //Variable to control loop
        boolean running = true;
                
        //Main menu loop
        while (running) {
            System.out.println("\nMain Menu");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("Choose an option");
            
            int choice = input.nextInt();
            input.nextLine(); 
            
            switch (choice) {
                case 1: //User registration
                    //Ask the user for registration details
                    System.out.print("Enter first name: ");
                    String firstName = input.nextLine();
                    
                    System.out.print("Enter last name: ");
                    String lastName = input.nextLine();

                    System.out.print("Enter username: ");
                    String username = input.nextLine();

                    System.out.print("Enter password: ");
                    String password = input.nextLine();

                    System.out.print("Enter SA cell number (+27): ");
                    String cellPhoneNumber = input.nextLine();

                    // Register the user
                    String registerMessage = login.registerUser(firstName, lastName, username, password, cellPhoneNumber);
                    System.out.println(registerMessage);
                    break;
                    
                case 2: //Registration verificatin
                    //Check if the user is registered
                    if (login.isRegistered()) {
                        System.out.println("No user registered yet. Please register first");
                        break;
                    }
                    
                    //Login user
                    System.out.print("Enter username: ");
                    String enteredUsername = input.nextLine();
                    
                    System.out.print("Enter password: ");
                    String enteredPassword = input.nextLine();
                    
                    //Login successful
                    boolean loginSuccess = login.loginUser(enteredUsername, enteredPassword);
                    
                    //Login results
                    System.out.println(login.returnLoginStatus(loginSuccess));
                    break;
                    
                case 3: 
                    //exit program 
                    System.out.println("Goodbye");
                    running = false;
                    break; 
                    
                default: //incase of incorrect selection 
                    System.out.println("invalid option selected. Please choose 1, 2, or 3.");
                    
            }
        } 
            
            
        input.close();
        
       
    }    
}
