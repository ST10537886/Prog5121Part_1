import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

// Test class for Login
public class LoginTest {

    @Test
    public void testCheckUserNameCorrectlyFormatted() {
        LoginProg5121part1 login = new LoginProg5121part1();
        assertTrue(login.checkUserName("a_b"));
    }

    @Test
    public void testCheckUserNameIncorrectlyFormatted() {
        LoginProg5121part1 login = new LoginProg5121part1();
        assertFalse(login.checkUserName("abcde1"));
    }

    @Test
    public void testCheckPasswordComplexityCorrect() {
        LoginProg5121part1 login = new LoginProg5121part1();
        assertTrue(login.checkPasswordComplexity("Passw0rd!"));
    }

    @Test
    public void testCheckPasswordComplexityIncorrect() {
        LoginProg5121part1 login = new LoginProg5121part1();
        assertFalse(login.checkPasswordComplexity("password"));
    }

    @Test
    public void testCheckCellPhoneNumberCorrect() {
        LoginProg5121part1 login = new LoginProg5121part1();
        assertTrue(login.checkCellPhoneNumber("+27831234567"));
    }

    @Test
    public void testCheckCellPhoneNumberIncorrect() {
        LoginProg5121part1 login = new LoginProg5121part1();
        assertFalse(login.checkCellPhoneNumber("0831234567"));
    }

    @Test
    public void testRegisterUserSuccess() {
        LoginProg5121part1 login = new LoginProg5121part1();
        String result = login.registerUser("Lizzy", "Maake", "a_b", "Passw0rd!", "+27831234567");
        assertEquals("User registered successfully.", result);
    }

    @Test
    public void testLoginUserSuccess() {
        LoginProg5121part1 login = new LoginProg5121part1();
        login.registerUser("Lizzy", "Maake", "a_b", "Passw0rd!", "+27831234567");
        assertTrue(login.loginUser("a_b", "Passw0rd!"));
    }

    @Test
    public void testLoginUserFail() {
        LoginProg5121part1 login = new LoginProg5121part1();
        login.registerUser("Lizzy", "Maake", "a_b", "Passw0rd!", "+27831234567");
        assertFalse(login.loginUser("a_b", "wrongPass1!"));
    }
}




